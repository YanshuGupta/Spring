package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Customer;

public interface CustomerService {

	List<Customer> findAll();

}