package com.bmc;

public class Schedular {
	
	public void printMsg(String msg) {
		 
		System.out.println("Schedular : " + msg);
	}

}
